Extract all the files in the same location otherwise it won't work!
Make sure you have administrator rights!
Original Creator: GeTeDsTeR
https://www.twitter.com/getedster_
https://www.instagram.com/getedsta/
https://www.youtube.com/channel/UCAbzLO2gzgIHqiOFc1aiWyA
https://www.youtube.com/channel/UCb48khbOfJo-j6FWX_8VqFA
https://arschs.wixsite.com/gtdm
https://arschs.wixsite.com/kiwa (pass: nein)
https://arschs.wixsite.com/kiwaspa